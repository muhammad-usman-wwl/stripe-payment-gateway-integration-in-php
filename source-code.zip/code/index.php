<?php require __DIR__ . '/products.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>My Store — Pay with Stripe</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

<div class="container py-5" style="max-width: 960px;">
    <div class="d-flex justify-content-between align-items-center mb-1">
        <h1 class="fw-bold">My Store</h1>
        <span class="badge bg-warning text-dark fs-6">Stripe TEST mode</span>
    </div>
    <p class="text-muted mb-4">Secure checkout powered by Stripe. You never type card details on this site — Stripe collects them on its own secure page.</p>

    <div class="row g-4">
        <?php foreach ($PRODUCTS as $id => $p): ?>
        <div class="col-md-4">
            <div class="card h-100 shadow-sm">
                <div class="card-body d-flex flex-column">
                    <h5 class="card-title"><?= htmlspecialchars($p['name']) ?></h5>
                    <p class="card-text text-muted"><?= htmlspecialchars($p['description']) ?></p>
                    <div class="mt-auto">
                        <div class="fs-3 fw-bold mb-3">$<?= number_format($p['price'] / 100, 2) ?></div>
                        <form action="create-checkout-session.php" method="POST">
                            <input type="hidden" name="product" value="<?= htmlspecialchars($id) ?>">
                            <button type="submit" class="btn btn-primary w-100">Pay with Stripe</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>

    <p class="text-muted small mt-4">Demo store from the tutorial "Stripe Payment Gateway Integration in PHP" — Simplified Dev Code Camp.</p>
</div>

</body>
</html>
