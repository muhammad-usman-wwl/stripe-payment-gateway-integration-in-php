<?php
// ============================================================
//  create-checkout-session.php
//  Creates a Stripe Checkout Session on OUR server, then
//  redirects the customer to Stripe's hosted checkout page.
//  The secret key never leaves the server.
// ============================================================

require __DIR__ . '/config.php';
require __DIR__ . '/products.php';
require __DIR__ . '/stripe-php/init.php';   // official Stripe PHP SDK

// 1) Which product did the customer choose?
$productId = $_POST['product'] ?? '';
if (!isset($PRODUCTS[$productId])) {
    http_response_code(400);
    exit('Invalid product.');
}
$product = $PRODUCTS[$productId];

// 2) Talk to Stripe with OUR secret key.
\Stripe\Stripe::setApiKey(STRIPE_SECRET_KEY);

try {
    // 3) Create the Checkout Session.
    $session = \Stripe\Checkout\Session::create([
        'mode' => 'payment',
        'line_items' => [[
            'price_data' => [
                'currency'     => $product['currency'],
                'product_data' => [
                    'name'        => $product['name'],
                    'description' => $product['description'],
                ],
                'unit_amount'  => $product['price'],  // in cents
            ],
            'quantity' => 1,
        ]],
        // {CHECKOUT_SESSION_ID} is replaced by Stripe itself.
        'success_url' => BASE_URL . '/success.php?session_id={CHECKOUT_SESSION_ID}',
        'cancel_url'  => BASE_URL . '/cancel.php',
    ]);

    // 4) Send the customer to Stripe's secure checkout page.
    header('Location: ' . $session->url, true, 303);
    exit;

} catch (\Stripe\Exception\ApiErrorException $e) {
    // Wrong key, network problem, invalid data — show a clean
    // message instead of a broken page. (Log $e->getMessage()
    // on a real site; never show secret details to customers.)
    http_response_code(500);
    echo '<h1>Payment could not be started</h1>';
    echo '<p>Please check that your Stripe test keys in config.php are correct, then try again.</p>';
    exit;
}
