<?php

namespace Stripe;

/**
 * Class ApiRequestor.
 */
class ApiRequestor
{
    /**
     * @var null|string
     */
    private $_apiKey;

    /**
     * @var string
     */
    private $_apiBase;

    /**
     * @var null|array
     */
    private $_appInfo;

    /**
     * @var HttpClient\ClientInterface
     */
    private static $_httpClient;
    /**
     * @var HttpClient\StreamingClientInterface
     */
    private static $_streamingHttpClient;

    /**
     * @var RequestTelemetry
     */
    private static $requestTelemetry;

    private static $OPTIONS_KEYS = ['api_key', 'idempotency_key', 'stripe_account', 'stripe_context', 'stripe_version', 'api_base'];

    /**
     * ApiRequestor constructor.
     *
     * @param null|string $apiKey
     * @param null|string $apiBase
     * @param null|array $appInfo
     */
    public function __construct($apiKey = null, $apiBase = null, $appInfo = null)
    {
        $this->_apiKey = $apiKey;
        if (!$apiBase) {
            $apiBase = Stripe::$apiBase;
        }
        $this->_apiBase = $apiBase;
        $this->_appInfo = $appInfo;
    }

    /**
     * Creates a telemetry json blob for use in 'X-Stripe-Client-Telemetry' headers.
     *
     * @static
     *
     * @param RequestTelemetry $requestTelemetry
     *
     * @return string
     */
    private static function _telemetryJson($requestTelemetry)
    {
        $payload = [
            'last_request_metrics' => [
                'request_id' => $requestTelemetry->requestId,
                'request_duration_ms' => $requestTelemetry->requestDuration,
            ],
        ];
        if (\count($requestTelemetry->usage) > 0) {
            $payload['last_request_metrics']['usage'] = $requestTelemetry->usage;
        }

        $result = \json_encode($payload);
        if (false !== $result) {
            return $result;
        }
        Stripe::getLogger()->error('Serializing telemetry payload failed!');

        return '{}';
    }

    /**
     * @static
     *
     * @param ApiResource|array|bool|mixed $d
     *
     * @return ApiResource|array|mixed|string
     */
    private static function _encodeObjects($d)
    {
        if ($d instanceof ApiResource) {
            return Util\Util::utf8($d->id);
        }
        if (true === $d) {
            return 'true';
        }
        if (false === $d) {
            return 'false';
        }
        if (\is_array($d)) {
            $res = [];
            foreach ($d as $k => $v) {
                $res[$k] = self::_encodeObjects($v);
            }

            return $res;
        }

        return Util\Util::utf8($d);
    }

    /**
     * @param 'delete'|'get'|'post'     $method
     * @param string     $url
     * @param null|array $params
     * @param null|array $headers
     * @param 'v1'|'v2' $apiMode
     * @param string[] $usage
     * @param null|int $maxNetworkRetries
     *
     * @return array tuple containing (ApiReponse, API key)
     *
     * @throws Exception\ApiErrorException
     */
    public function request($method, $url, $params = null, $headers = null, $apiMode = 'v1', $usage = [], $maxNetworkRetries = null)
    {
        $params = $params ?: [];
        $headers = $headers ?: [];
        list($rbody, $rcode, $rheaders, $myApiKey)
            = $this->_requestRaw($method, $url, $params, $headers, $apiMode, $usage, $maxNetworkRetries);
        $this->_maybeEmitStripeNotice($rheaders);
        $json = $this->_interpretResponse($rbody, $rcode, $rheaders, $apiMode);
        $resp = new ApiResponse($rbody, $rcode, $rheaders, $json);

        return [$resp, $myApiKey];
    }

    /**
     * @param 'delete'|'get'|'post' $method
     * @param string     $url
     * @param callable $readBodyChunkCallable
     * @param null|array $params
     * @param null|array $headers
     * @param 'v1'|'v2' $apiMode
     * @param string[] $usage
     * @param null|int $maxNetworkRetries
     *
     * @throws Exception\ApiErrorException
     */
    public function requestStream($method, $url, $readBodyChunkCallable, $params = null, $headers = null, $apiMode = 'v1', $usage = [], $maxNetworkRetries = null)
    {
        $params = $params ?: [];
        $headers = $headers ?: [];
        list($rbody, $rcode, $rheaders, $myApiKey)
            = $this->_requestRawStreaming($method, $url, $params, $headers, $apiMode, $usage, $readBodyChunkCallable, $maxNetworkRetries);
        $this->_maybeEmitStripeNotice($rheaders);
        if ($rcode >= 300) {
            $this->_interpretResponse($rbody, $rcode, $rheaders, $apiMode);
        }
    }

    /**
     * @param string $rbody a JSON string
     * @param int $rcode
     * @param array $rheaders
     * @param array $resp
     * @param 'v1'|'v2' $apiMode
     *
     * @throws Exception\UnexpectedValueException
     * @throws Exception\ApiErrorException
     */
    public function handleErrorResponse($rbody, $rcode, $rheaders, $resp, $apiMode)
    {
        if (!\is_array($resp) || !isset($resp['error'])) {
            $msg = "Invalid response object from API: {$rbody} "
                . "(HTTP response code was {$rcode})";

            throw new Exception\UnexpectedValueException($msg);
        }

        $errorData = $resp['error'];

        $error = null;

        if (\is_string($errorData)) {
            $error = self::_specificOAuthError($rbody, $rcode, $rheaders, $resp, $errorData);
        }
        if (!$error) {
            $error = 'v1' === $apiMode ? self::_specificV1APIError($rbody, $rcode, $rheaders, $resp, $errorData) : self::_specificV2APIError($rbody, $rcode, $rheaders, $resp, $errorData);
        }

        throw $error;
    }

    /**
     * @static
     *
     * @param string $rbody
     * @param int    $rcode
     * @param array  $rheaders
     * @param array  $resp
     * @param array  $errorData
     *
     * @return Exception\ApiErrorException
     */
    private static function _specificV1APIError($rbody, $rcode, $rheaders, $resp, $errorData)
    {
        $msg = isset($errorData['message']) ? $errorData['message'] : null;
        $param = isset($errorData['param']) ? $errorData['param'] : null;
        $code = isset($errorData['code']) ? $errorData['code'] : null;
        $type = isset($errorData['type']) ? $errorData['type'] : null;
        $declineCode = isset($errorData['decline_code']) ? $errorData['decline_code'] : null;

        switch ($rcode) {
            case 400:
                // 'rate_limit' code is deprecated, but left here for backwards compatibility
                // for API versions earlier than 2015-09-08
                if ('rate_limit' === $code) {
                    return Exception\RateLimitException::factory($msg, $rcode, $rbody, $resp, $rheaders, $code, $param);
                }
                if ('idempotency_error' === $type) {
                    return Exception\IdempotencyException::factory($msg, $rcode, $rbody, $resp, $rheaders, $code);
                }

                // fall through in generic 400 or 404, returns InvalidRequestException by default
                // no break
            case 404:
                return Exception\InvalidRequestException::factory($msg, $rcode, $rbody, $resp, $rheaders, $code, $param);

            case 401:
                return Exception\AuthenticationException::factory($msg, $rcode, $rbody, $resp, $rheaders, $code);

            case 402:
                return Exception\CardException::factory($msg, $rcode, $rbody, $resp, $rheaders, $code, $declineCode, $param);

            case 403:
                return Exception\PermissionException::factory($msg, $rcode, $rbody, $resp, $rheaders, $code);

            case 429:
                return Exception\RateLimitException::factory($msg, $rcode, $rbody, $resp, $rheaders, $code, $param);

            default:
                return Exception\UnknownApiErrorException::factory($msg, $rcode, $rbody, $resp, $rheaders, $code);
        }
    }

    /**
     * @static
     *
     * @param string $rbody
     * @param int    $rcode
     * @param array  $rheaders
     * @param array  $resp
     * @param array  $errorData
     *
     * @return Exception\ApiErrorException
     */
    private static function _specificV2APIError($rbody, $rcode, $rheaders, $resp, $errorData)
    {
        $msg = isset($errorData['message']) ? $errorData['message'] : null;
        $code = isset($errorData['code']) ? $errorData['code'] : null;
        $type = isset($errorData['type']) ? $errorData['type'] : null;

        switch ($type) {
            case 'idempotency_error':
                return Exception\IdempotencyException::factory($msg, $rcode, $rbody, $resp, $rheaders, $code);

                // switchCases: The beginning of the section generated from our OpenAPI spec
            case 'already_canceled':
                return Exception\AlreadyCanceledException::factory(
                    $msg,
                    $rcode,
                    $rbody,
                    $resp,
                    $rheaders,
                    $code
                );

            case 'blocked_by_stripe':
                return Exception\BlockedByStripeException::factory(
                    $msg,
                    $rcode,
                    $rbody,
                    $resp,
                    $rheaders,
                    $code
                );

            case 'cannot_proceed':
                $reason = isset($errorData['reason']) ? $errorData['reason'] : null;

                return Exception\CannotProceedException::factory(
                    $msg,
                    $rcode,
                    $rbody,
                    $resp,
                    $rheaders,
                    $code,
                    $reason
                );

            case 'capability_not_enabled':
                return Exception\CapabilityNotEnabledException::factory(
                    $msg,
                    $rcode,
                    $rbody,
                    $resp,
                    $rheaders,
                    $code
                );

            case 'controlled_by_alternate_resource':
                return Exception\ControlledByAlternateResourceException::factory(
                    $msg,
                    $rcode,
                    $rbody,
                    $resp,
                    $rheaders,
                    $code
                );

            case 'feature_not_enabled':
                return Exception\FeatureNotEnabledException::factory(
                    $msg,
                    $rcode,
                    $rbody,
                    $resp,
                    $rheaders,
                    $code
                );

            case 'financial_account_not_open':
                return Exception\FinancialAccountNotOpenException::factory(
                    $msg,
                    $rcode,
                    $rbody,
                    $resp,
                    $rheaders,
                    $code
                );

            case 'fx_quote_needs_refresh':
                return Exception\FxQuoteNeedsRefreshException::factory(
                    $msg,
                    $rcode,
                    $rbody,
                    $resp,
                    $rheaders,
                    $code
                );

            case 'insufficient_funds':
                return Exception\InsufficientFundsException::factory(
                    $msg,
                    $rcode,
                    $rbody,
                    $resp,
                    $rheaders,
                    $code
                );

            case 'invalid_payment_method':
                $invalidParam = isset($errorData['invalid_param']) ? $errorData['invalid_param'] : null;

                return Exception\InvalidPaymentMethodException::factory(
                    $msg,
                    $rcode,
                    $rbody,
                    $resp,
                    $rheaders,
                    $code,
                    $invalidParam
                );

            case 'invalid_payout_method':
                return Exception\InvalidPayoutMethodException::factory(
                    $msg,
                    $rcode,
                    $rbody,
                    $resp,
                    $rheaders,
                    $code
                );

            case 'invalid_vaulted_credential':
                $invalidParam = isset($errorData['invalid_param']) ? $errorData['invalid_param'] : null;

                return Exception\InvalidVaultedCredentialException::factory(
                    $msg,
                    $rcode,
                    $rbody,
                    $resp,
                    $rheaders,
                    $code,
                    $invalidParam
                );

            case 'not_cancelable':
                return Exception\NotCancelableException::factory(
                    $msg,
                    $rcode,
                    $rbody,
                    $resp,
                    $rheaders,
                    $code
                );

            case 'quota_exceeded':
                return Exception\QuotaExceededException::factory(
                    $msg,
                    $rcode,
                    $rbody,
                    $resp,
                    $rheaders,
                    $code
                );

            case 'rate_limit':
                return Exception\RateLimitException::factory(
                    $msg,
                    $rcode,
                    $rbody,
                    $resp,
                    $rheaders,
                    $code
                );

            case 'recipient_not_notifiable':
                return Exception\RecipientNotNotifiableException::factory(
                    $msg,
                    $rcode,
                    $rbody,
                    $resp,
                    $rheaders,
                    $code
                );

            case 'temporary_session_expired':
                return Exception\TemporarySessionExpiredException::factory(
                    $msg,
                    $rcode,
                    $rbody,
                    $resp,
                    $rheaders,
                    $code
                );

            case 'verification_attempt_failed':
                $verificationStatus = isset($errorData['verification_status']) ? $errorData['verification_status'] : null;

                return Exception\VerificationAttemptFailedException::factory(
                    $msg,
                    $rcode,
                    $rbody,
                    $resp,
                    $rheaders,
                    $code,
                    $verificationStatus
                );

            case 'verification_expired':
                $verificationStatus = isset($errorData['verification_status']) ? $errorData['verification_status'] : null;

                return Exception\VerificationExpiredException::factory(
                    $msg,
                    $rcode,
                    $rbody,
                    $resp,
                    $rheaders,
                    $code,
                    $verificationStatus
                );

            case 'verification_not_initiated':
                $verificationStatus = isset($errorData['verification_status']) ? $errorData['verification_status'] : null;

                return Exception\VerificationNotInitiatedException::factory(
                    $msg,
                    $rcode,
                    $rbody,
                    $resp,
                    $rheaders,
                    $code,
                    $verificationStatus
                );

                // switchCases: The end of the section generated from our OpenAPI spec
            default:
                return self::_specificV1APIError($rbody, $rcode, $rheaders, $resp, $errorData);
        }
    }

    /**
     * @static
     *
     * @param bool|string $rbody
     * @param int         $rcode
     * @param array       $rheaders
     * @param array       $resp
     * @param string      $errorCode
     *
     * @return Exception\OAuth\OAuthErrorException
     */
    private static function _specificOAuthError($rbody, $rcode, $rheaders, $resp, $errorCode)
    {
        $description = isset($resp['error_description']) ? $resp['error_description'] : $errorCode;

        switch ($errorCode) {
            case 'invalid_client':
                return Exception\OAuth\InvalidClientException::factory($description, $rcode, $rbody, $resp, $rheaders, $errorCode);

            case 'invalid_grant':
                return Exception\OAuth\InvalidGrantException::factory($description, $rcode, $rbody, $resp, $rheaders, $errorCode);

            case 'invalid_request':
                return Exception\OAuth\InvalidRequestException::factory($description, $rcode, $rbody, $resp, $rheaders, $errorCode);

            case 'invalid_scope':
                return Exception\OAuth\InvalidScopeException::factory($description, $rcode, $rbody, $resp, $rheaders, $errorCode);

            case 'unsupported_grant_type':
                return Exception\OAuth\UnsupportedGrantTypeException::factory($description, $rcode, $rbody, $resp, $rheaders, $errorCode);

            case 'unsupported_response_type':
                return Exception\OAuth\UnsupportedResponseTypeException::factory($description, $rcode, $rbody, $resp, $rheaders, $errorCode);

            default:
                return Exception\OAuth\UnknownOAuthErrorException::factory($description, $rcode, $rbody, $resp, $rheaders, $errorCode);
        }
    }

    /**
     * @static
     *
     * @param null|array $appInfo
     *
     * @return null|string
     */
    private static function _formatAppInfo($appInfo)
    {
        if (null !== $appInfo) {
            $string = $appInfo['name'];
            if (\array_key_exists('version', $appInfo) && null !== $appInfo['version']) {
                $string .= '/' . $appInfo['version'];
            }
            if (\array_key_exists('url', $appInfo) && null !== $appInfo['url']) {
                $string .= ' (' . $appInfo['url'] . ')';
            }

            return $string;
        }

        return null;
    }

    /**
     * @static
     *
     * @param string $disableFunctionsOutput - String value of the 'disable_function' setting, as output by \ini_get('disable_functions')
     * @param string $functionName - Name of the function we are interesting in seeing whether or not it is disabled
     *
     * @return bool
     */
    private static function _isDisabled($disableFunctionsOutput, $functionName)
    {
        $disabledFunctions = \explode(',', $disableFunctionsOutput);
        foreach ($disabledFunctions as $disabledFunction) {
            if (\trim($disabledFunction) === $functionName) {
                return true;
            }
        }

        return false;
    }

    /**
     * @static
     *
     * @return string the detected AI agent slug, or empty string if none detected
     */
    const AI_AGENTS = [
        // aiAgents: The beginning of the section generated from our OpenAPI spec
        ['ANTIGRAVITY_CLI_ALIAS', 'antigravity'],
        ['CLAUDECODE', 'claude_code'],
        ['CLINE_ACTIVE', 'cline'],
        ['CODEX_SANDBOX', 'codex_cli'],
        ['CODEX_THREAD_ID', 'codex_cli'],
        ['CODEX_SANDBOX_NETWORK_DISABLED', 'codex_cli'],
        ['CODEX_CI', 'codex_cli'],
        ['CURSOR_AGENT', 'cursor'],
        ['GEMINI_CLI', 'gemini_cli'],
        ['HERMES_AGENT', 'hermes'],
        ['OPENCLAW_SHELL', 'openclaw'],
        ['OPENCODE', 'open_code'],
        // aiAgents: The end of the section generated from our OpenAPI spec
    ];

    private static function _detectAIAgent($getEnv = null)
    {
        if (null === $getEnv) {
            $getEnv = '\getenv';
        }
        foreach (self::AI_AGENTS as $agent) {
            $val = $getEnv($agent[0]);
            if (false !== $val && '' !== $val) {
                return $agent[1];
            }
        }

        return '';
    }

    /**
     * @static
     *
     * @param string     $apiKey the Stripe API key, to be used in regular API requests
     * @param null       $clientInfo client user agent information
     * @param null       $appInfo information to identify a plugin that integrates Stripe using this library
     * @param 'v1'|'v2' $apiMode
     *
     * @return array
     */
    private static function _defaultHeaders($apiKey, $clientInfo = null, $appInfo = null, $apiMode = 'v1')
    {
        $uaString = "Stripe/{$apiMode} PhpBindings/" . Stripe::VERSION;

        $langVersion = \PHP_VERSION;

        // Fallback to global configuration to maintain backwards compatibility.
        $appInfo = $appInfo ?: Stripe::getAppInfo();

        $ua = [
            'bindings_version' => Stripe::VERSION,
            'lang' => 'php',
            'lang_version' => $langVersion,
        ];
        if (Stripe::getEnableTelemetry()) {
            $telemetryId = TelemetryId::get();
            if (null !== $telemetryId) {
                $ua['telemetry_id'] = $telemetryId;
            }
            $uname_disabled = self::_isDisabled(\ini_get('disable_functions'), 'php_uname');
            $ua['platform'] = $uname_disabled
                ? '(disabled)'
                // only get general platform information, e.g. `Darwin 25.3.0 arm64`
                : \php_uname('s') . ' ' . \php_uname('r') . ' ' . \php_uname('m');
        }
        if ($clientInfo) {
            $ua = \array_merge($clientInfo, $ua);
        }
        if (null !== $appInfo) {
            $uaString .= ' ' . self::_formatAppInfo($appInfo);
            $ua['application'] = $appInfo;
        }

        $aiAgent = self::_detectAIAgent();
        if ('' !== $aiAgent) {
            $uaString .= ' AIAgent/' . $aiAgent;
            $ua['ai_agent'] = $aiAgent;
        }

        return [
            'X-Stripe-Client-User-Agent' => \json_encode($ua),
            'User-Agent' => $uaString,
            'Authorization' => 'Bearer ' . $apiKey,
            'Stripe-Version' => Stripe::getApiVersion(),
        ];
    }

    /**
     * Asserts that a request path is origin-relative: that it begins with a
     * single "/" and carries no scheme, authority or userinfo.
     *
     * The absolute URL is built by concatenating the API base onto this path,
     * and no base URL ends in a slash. A path like "@evil.example/v1/x" or
     * ".evil.example/v1/x" would modify the resulting host and direct the
     * request (including the API key) to a non-Stripe host.
     *
     * Because some relative urls arrive from potentially untrusted sources (like
     * webhook bodies), we have to be a little defensive.
     *
     * So, we require that a path starts with a leading slash and that
     * parse_url() finds no scheme or authority in it.
     *
     * @param string $url
     *
     * @throws Exception\InvalidArgumentException
     */
    private static function validatePath($url)
    {
        if (!\is_string($url) || '/' !== \substr($url, 0, 1) || '//' === \substr($url, 0, 2)) {
            throw new Exception\InvalidArgumentException(
                'Request path must be a string beginning with a single "/".'
            );
        }

        $parts = \parse_url($url);
        if (false === $parts || isset($parts['scheme']) || isset($parts['host']) || isset($parts['user'])) {
            throw new Exception\InvalidArgumentException(
                'Request path may not contain a scheme or authority.'
            );
        }
    }

    /**
     * Rejects CR, LF and NUL in a header name or value.
     *
     * Header lines are assembled by concatenation, so a newline in either half
     * would let the remainder be parsed as additional headers. Some of these
     * values originate in remote data - fetchRelatedObject() sets Stripe-Context
     * and Stripe-Request-Trigger from the webhook body - and a per-request
     * api_key reaches the Authorization value without the whitespace check that
     * Stripe::setApiKey() applies.
     *
     * @param string $header
     * @param mixed  $value
     *
     * @throws Exception\InvalidArgumentException
     */
    private static function assertNoHeaderInjection($header, $value)
    {
        foreach ([$header, $value] as $part) {
            if (!\is_string($part)) {
                continue;
            }

            if (false !== \strpbrk($part, "\r\n") || false !== \strpos($part, "\0")) {
                throw new Exception\InvalidArgumentException(
                    'Header names and values may not contain CR, LF or NUL characters.'
                );
            }
        }
    }

    /**
     * @param 'delete'|'get'|'post' $method
     * @param string $url
     * @param array $params
     * @param array $headers
     * @param 'v1'|'v2' $apiMode
     */
    private function _prepareRequest($method, $url, $params, $headers, $apiMode)
    {
        Util\AgentPluginHint::maybeEmit();

        $myApiKey = $this->_apiKey;
        if (!$myApiKey) {
            $myApiKey = Stripe::$apiKey;
        }

        Util\RequestOptions::assertApiKeyAttached($myApiKey);

        if (!$myApiKey) {
            $msg = 'No API key provided.  (HINT: set your API key using '
                . '"Stripe::setApiKey(<API-KEY>)".  You can generate API keys from '
                . 'the Stripe web interface.  See https://stripe.com/api for '
                . 'details, or email support@stripe.com if you have any questions.';

            throw new Exception\AuthenticationException($msg);
        }

        // Clients can supply arbitrary additional keys to be included in the
        // X-Stripe-Client-User-Agent header via the optional getUserAgentInfo()
        // method
        $clientUAInfo = null;
        if (\method_exists(self::httpClient(), 'getUserAgentInfo')) {
            $clientUAInfo = self::httpClient()->getUserAgentInfo();
        }

        if ($params && \is_array($params)) {
            $optionKeysInParams = \array_filter(
                self::$OPTIONS_KEYS,
                static function ($key) use ($params) {
                    return \array_key_exists($key, $params);
                }
            );
            if (\count($optionKeysInParams) > 0) {
                $message = \sprintf('Options found in $params: %s. Options should '
                    . 'be passed in their own array after $params. (HINT: pass an '
                    . 'empty array to $params if you do not have any.)', \implode(', ', $optionKeysInParams));
                \trigger_error($message, \E_USER_WARNING);
            }
        }

        self::validatePath($url);
        $absUrl = $this->_apiBase . $url;
        if ('v1' === $apiMode) {
            $params = self::_encodeObjects($params);
        }
        $defaultHeaders = $this->_defaultHeaders($myApiKey, $clientUAInfo, $this->_appInfo, $apiMode);

        if (Stripe::$accountId) {
            $defaultHeaders['Stripe-Account'] = Stripe::$accountId;
        }

        if (Stripe::$enableTelemetry && null !== self::$requestTelemetry) {
            $defaultHeaders['X-Stripe-Client-Telemetry'] = self::_telemetryJson(self::$requestTelemetry);
        }

        $hasFile = false;
        foreach ($params as $k => $v) {
            if (\is_resource($v)) {
                $hasFile = true;
                $params[$k] = self::_processResourceParam($v);
            } elseif ($v instanceof \CURLFile) {
                $hasFile = true;
            }
        }

        if ($hasFile) {
            $defaultHeaders['Content-Type'] = 'multipart/form-data';
        } elseif ('v2' === $apiMode) {
            $defaultHeaders['Content-Type'] = 'application/json';
        } elseif ('v1' === $apiMode) {
            $defaultHeaders['Content-Type'] = 'application/x-www-form-urlencoded';
        } else {
            throw new Exception\InvalidArgumentException('Unknown API mode: ' . $apiMode);
        }

        $combinedHeaders = \array_merge($defaultHeaders, $headers);

        // Remove the explicit-clear sentinel after it overrides the process-global account.
        if (isset($combinedHeaders['Stripe-Account']) && Util\RequestOptions::STRIPE_ACCOUNT_UNSET === $combinedHeaders['Stripe-Account']) {
            unset($combinedHeaders['Stripe-Account']);
        }

        $rawHeaders = [];

        foreach ($combinedHeaders as $header => $value) {
            self::assertNoHeaderInjection($header, $value);
            $rawHeaders[] = $header . ': ' . $value;
        }

        return [$absUrl, $rawHeaders, $params, $hasFile, $myApiKey];
    }

    private function _maybeEmitStripeNotice($rheaders, $getEnv = null)
    {
        if (!isset($rheaders['stripe-notice']) || !\is_string($rheaders['stripe-notice'])) {
            return;
        }

        if (null === $getEnv) {
            $getEnv = '\getenv';
        }

        $aiAgent = self::_detectAIAgent($getEnv);
        $suppressionValue = $getEnv('STRIPE_SUPPRESS_NOTICES');
        $shouldSuppress = '' === $aiAgent
            && false !== $suppressionValue
            && 'true' === \strtolower($suppressionValue);
        if ($shouldSuppress) {
            return;
        }

        $notice = $rheaders['stripe-notice'];
        if ('' === $aiAgent) {
            $notice .= "\nTo suppress Stripe notices in test and sandbox environments, set the STRIPE_SUPPRESS_NOTICES environment variable to true.";
        }

        \trigger_error($notice, \E_USER_WARNING);
    }

    /**
     * @param 'delete'|'get'|'post' $method
     * @param string $url
     * @param array $params
     * @param array $headers
     * @param 'v1'|'v2' $apiMode
     * @param string[] $usage
     * @param null|int $maxNetworkRetries
     *
     * @return array
     *
     * @throws Exception\AuthenticationException
     * @throws Exception\ApiConnectionException
     */
    private function _requestRaw($method, $url, $params, $headers, $apiMode, $usage, $maxNetworkRetries)
    {
        list($absUrl, $rawHeaders, $params, $hasFile, $myApiKey) = $this->_prepareRequest($method, $url, $params, $headers, $apiMode);

        // for some reason, PHP users will sometimes include null bytes in their paths, which leads to cryptic server 400s.
        // we'll be louder about this to help catch issues earlier.
        if (false !== \strpos($absUrl, "\0") || false !== \strpos($absUrl, '%00')) {
            throw new Exception\InvalidRequestException("URLs may not contain null bytes ('\\0'); double check any IDs you're including with the request.");
        }

        $requestStartMs = Util\Util::currentTimeMillis();

        list($rbody, $rcode, $rheaders) = self::httpClient()->request(
            $method,
            $absUrl,
            $rawHeaders,
            $params,
            $hasFile,
            $apiMode,
            $maxNetworkRetries
        );

        if (
            isset($rheaders['request-id'])
            && \is_string($rheaders['request-id'])
            && '' !== $rheaders['request-id']
        ) {
            self::$requestTelemetry = new RequestTelemetry(
                $rheaders['request-id'],
                Util\Util::currentTimeMillis() - $requestStartMs,
                $usage
            );
        }

        return [$rbody, $rcode, $rheaders, $myApiKey];
    }

    /**
     * @param 'delete'|'get'|'post' $method
     * @param string $url
     * @param array $params
     * @param array $headers
     * @param string[] $usage
     * @param callable $readBodyChunkCallable
     * @param 'v1'|'v2' $apiMode
     * @param null|int $maxNetworkRetries
     *
     * @return array
     *
     * @throws Exception\AuthenticationException
     * @throws Exception\ApiConnectionException
     */
    private function _requestRawStreaming($method, $url, $params, $headers, $apiMode, $usage, $readBodyChunkCallable, $maxNetworkRetries)
    {
        list($absUrl, $rawHeaders, $params, $hasFile, $myApiKey) = $this->_prepareRequest($method, $url, $params, $headers, $apiMode);

        $requestStartMs = Util\Util::currentTimeMillis();

        list($rbody, $rcode, $rheaders) = self::streamingHttpClient()->requestStream(
            $method,
            $absUrl,
            $rawHeaders,
            $params,
            $hasFile,
            $readBodyChunkCallable,
            $apiMode,
            $maxNetworkRetries
        );

        if (
            isset($rheaders['request-id'])
            && \is_string($rheaders['request-id'])
            && '' !== $rheaders['request-id']
        ) {
            self::$requestTelemetry = new RequestTelemetry(
                $rheaders['request-id'],
                Util\Util::currentTimeMillis() - $requestStartMs
            );
        }

        return [$rbody, $rcode, $rheaders, $myApiKey];
    }

    /**
     * @param resource $resource
     *
     * @return \CURLFile|string
     *
     * @throws Exception\InvalidArgumentException
     */
    private function _processResourceParam($resource)
    {
        if ('stream' !== \get_resource_type($resource)) {
            throw new Exception\InvalidArgumentException(
                'Attempted to upload a resource that is not a stream'
            );
        }

        $metaData = \stream_get_meta_data($resource);
        if ('plainfile' !== $metaData['wrapper_type']) {
            throw new Exception\InvalidArgumentException(
                'Only plainfile resource streams are supported'
            );
        }

        // We don't have the filename or mimetype, but the API doesn't care
        return new \CURLFile($metaData['uri']);
    }

    /**
     * @param string $rbody
     * @param int    $rcode
     * @param array  $rheaders
     * @param 'v1'|'v2'  $apiMode
     *
     * @return array
     *
     * @throws Exception\UnexpectedValueException
     * @throws Exception\ApiErrorException
     */
    private function _interpretResponse($rbody, $rcode, $rheaders, $apiMode)
    {
        $resp = \json_decode($rbody, true);
        $jsonError = \json_last_error();
        if (null === $resp && \JSON_ERROR_NONE !== $jsonError) {
            $msg = "Invalid response body from API: {$rbody} "
                . "(HTTP response code was {$rcode}, json_last_error() was {$jsonError})";

            throw new Exception\UnexpectedValueException($msg, $rcode);
        }

        if ($rcode < 200 || $rcode >= 300) {
            $this->handleErrorResponse($rbody, $rcode, $rheaders, $resp, $apiMode);
        }

        return $resp;
    }

    /**
     * @static
     *
     * @param HttpClient\ClientInterface $client
     */
    public static function setHttpClient($client)
    {
        self::$_httpClient = $client;
    }

    /**
     * @static
     *
     * @param HttpClient\StreamingClientInterface $client
     */
    public static function setStreamingHttpClient($client)
    {
        self::$_streamingHttpClient = $client;
    }

    /**
     * @static
     *
     * Resets any stateful telemetry data
     */
    public static function resetTelemetry()
    {
        self::$requestTelemetry = null;
    }

    /**
     * @return HttpClient\ClientInterface
     */
    public static function httpClient()
    {
        if (!self::$_httpClient) {
            self::$_httpClient = HttpClient\CurlClient::instance();
        }

        return self::$_httpClient;
    }

    /**
     * @return HttpClient\StreamingClientInterface
     */
    public static function streamingHttpClient()
    {
        if (!self::$_streamingHttpClient) {
            self::$_streamingHttpClient = HttpClient\CurlClient::instance();
        }

        return self::$_streamingHttpClient;
    }
}
