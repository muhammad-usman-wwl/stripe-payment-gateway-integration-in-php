<?php

// File generated from our OpenAPI spec

namespace Stripe\Events;

class V1CustomerDiscountSourceChangedEvent extends \Stripe\V2\Core\Event
{
    const LOOKUP_TYPE = 'v1.customer.discount.source_changed';
}
