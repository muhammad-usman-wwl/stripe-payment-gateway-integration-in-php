<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Payment Cancelled</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container py-5" style="max-width: 640px;">
    <div class="card shadow-sm text-center p-4">
        <div class="display-4 text-secondary mb-2">&#8635;</div>
        <h1 class="fw-bold">Payment cancelled</h1>
        <p class="text-muted">No charge was made. You closed the Stripe checkout page before paying — your card was not charged.</p>
        <a href="index.php" class="btn btn-primary mt-3">Back to store</a>
    </div>
</div>
</body>
</html>
