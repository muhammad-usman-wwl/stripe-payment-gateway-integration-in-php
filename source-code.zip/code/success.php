<?php
// ============================================================
//  success.php
//  Stripe sends the customer back here after checkout — but
//  a redirect alone proves NOTHING. Anyone can type this URL.
//  So we ask Stripe's server, with our secret key: was this
//  session really paid? Only then do we say "successful".
// ============================================================

require __DIR__ . '/config.php';
require __DIR__ . '/stripe-php/init.php';

$sessionId = $_GET['session_id'] ?? '';
$paid      = false;
$session   = null;
$error     = '';

if ($sessionId === '') {
    $error = 'No checkout session was provided.';
} else {
    \Stripe\Stripe::setApiKey(STRIPE_SECRET_KEY);
    try {
        $session = \Stripe\Checkout\Session::retrieve($sessionId);
        $paid    = ($session->payment_status === 'paid');
    } catch (\Stripe\Exception\ApiErrorException $e) {
        $error = 'We could not verify this payment with Stripe.';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= $paid ? 'Payment Successful' : 'Payment Status' ?></title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container py-5" style="max-width: 640px;">
    <?php if ($paid): ?>
        <div class="card shadow-sm text-center p-4">
            <div class="display-4 text-success mb-2">&#10004;</div>
            <h1 class="fw-bold">Payment successful</h1>
            <p class="text-muted">Thank you! Your payment was verified with Stripe.</p>
            <hr>
            <div class="text-start">
                <p class="mb-1"><strong>Amount paid:</strong>
                    <?= strtoupper($session->currency) ?> <?= number_format($session->amount_total / 100, 2) ?></p>
                <?php if (!empty($session->customer_details->email)): ?>
                <p class="mb-1"><strong>Email:</strong> <?= htmlspecialchars($session->customer_details->email) ?></p>
                <?php endif; ?>
                <p class="mb-0"><strong>Session:</strong> <code><?= htmlspecialchars($session->id) ?></code></p>
            </div>
            <a href="index.php" class="btn btn-primary mt-4">Back to store</a>
        </div>
    <?php else: ?>
        <div class="card shadow-sm text-center p-4">
            <div class="display-4 text-warning mb-2">!</div>
            <h1 class="fw-bold">Payment not completed</h1>
            <p class="text-muted"><?= htmlspecialchars($error !== '' ? $error : 'This checkout session has not been paid.') ?></p>
            <a href="index.php" class="btn btn-outline-primary mt-3">Back to store</a>
        </div>
    <?php endif; ?>
</div>
</body>
</html>
