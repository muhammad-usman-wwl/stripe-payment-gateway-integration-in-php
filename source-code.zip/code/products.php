<?php
// ============================================================
//  products.php — the product catalogue
//  Prices live ONLY here, on the server. The browser sends a
//  product id, never a price — so nobody can change a price
//  in the browser and pay less. Amounts are in CENTS:
//  4900 = $49.00 (Stripe always charges the smallest unit).
// ============================================================

$PRODUCTS = [
    'php-course' => [
        'name'        => 'Complete PHP Course',
        'description' => 'Lifetime access to the full PHP course',
        'price'       => 4900,   // $49.00
        'currency'    => 'usd',
    ],
    'laravel-ebook' => [
        'name'        => 'Laravel E-Book Bundle',
        'description' => 'Three practical Laravel e-books (PDF)',
        'price'       => 1900,   // $19.00
        'currency'    => 'usd',
    ],
    'code-review' => [
        'name'        => '1-on-1 Code Review Session',
        'description' => 'One hour of personal code review',
        'price'       => 7900,   // $79.00
        'currency'    => 'usd',
    ],
];
