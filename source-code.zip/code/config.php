<?php
// ============================================================
//  Stripe Payment Gateway Integration in PHP
//  config.php — your Stripe keys and site settings
// ============================================================
//
//  STEP 1: Create a free account at https://stripe.com
//  STEP 2: In the Stripe Dashboard go to:
//          Developers → API keys  (make sure TEST mode is ON)
//  STEP 3: Copy your OWN test keys below.
//
//  ⚠ NEVER share your secret key, never upload it to GitHub,
//    and never use a key you saw in a video or screenshot —
//    always use your own keys from your own dashboard.

define('STRIPE_PUBLISHABLE_KEY', 'pk_test_YOUR_PUBLISHABLE_KEY');
define('STRIPE_SECRET_KEY',      'sk_test_YOUR_SECRET_KEY');

// Webhook endpoint secret — you get this when you create a
// webhook endpoint in the dashboard (Developers → Webhooks),
// or from the Stripe CLI when you run:  stripe listen
define('STRIPE_WEBHOOK_SECRET',  'whsec_YOUR_WEBHOOK_SECRET');

// Your site's base URL — no trailing slash.
// • Built-in PHP server:  http://localhost:8000
// • XAMPP:                http://localhost/stripe-php
define('BASE_URL', 'http://localhost:8000');
