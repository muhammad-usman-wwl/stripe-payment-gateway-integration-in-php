<?php
// ============================================================
//  webhook.php
//  Stripe calls THIS file directly, server to server, when
//  something happens — for example a payment completes.
//  This is the most reliable signal of a real payment:
//  fulfil the order here, not on the success page.
//
//  Setup (test mode):
//   • Stripe CLI:  stripe listen --forward-to localhost:8000/webhook.php
//     → it prints a signing secret (whsec_...) for config.php
//   • Or Dashboard → Developers → Webhooks → add endpoint:
//     https://yourdomain.com/webhook.php
//     event: checkout.session.completed
// ============================================================

require __DIR__ . '/config.php';
require __DIR__ . '/stripe-php/init.php';

\Stripe\Stripe::setApiKey(STRIPE_SECRET_KEY);

// 1) Read the RAW request body — signature verification
//    needs the exact bytes Stripe sent, not parsed data.
$payload   = file_get_contents('php://input');
$sigHeader = $_SERVER['HTTP_STRIPE_SIGNATURE'] ?? '';

try {
    // 2) Verify: did this really come from Stripe, unchanged?
    $event = \Stripe\Webhook::constructEvent(
        $payload,
        $sigHeader,
        STRIPE_WEBHOOK_SECRET
    );
} catch (\UnexpectedValueException $e) {
    http_response_code(400);   // invalid payload
    exit;
} catch (\Stripe\Exception\SignatureVerificationException $e) {
    http_response_code(400);   // invalid signature — not from Stripe
    exit;
}

// 3) Handle the event.
if ($event->type === 'checkout.session.completed') {
    $session = $event->data->object;

    if ($session->payment_status === 'paid') {
        // ✅ FULFIL THE ORDER HERE, for example:
        // - mark the order as PAID in your database
        // - send the download link / confirmation email
        // Demo: append one line to a log file.
        $line = date('c') . ' PAID ' . $session->id . ' '
              . $session->amount_total . ' ' . $session->currency . PHP_EOL;
        file_put_contents(__DIR__ . '/orders.log', $line, FILE_APPEND);
    }
}

// 4) Always answer 200 quickly, or Stripe will keep retrying.
http_response_code(200);
echo 'Webhook received.';
